sigma.plugins.relativeSize
=====================

Plugin developed by [Anatoliy Stegniy](https://github.com/tsdaemon).

---

This plugin provides a method to change nodes size depending to their degree (number of relationships)
